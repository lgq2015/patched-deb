#Filza 3.6.1-22 - 64bit for rootlessJB3
Patched using jtool by @brynts
Source: https://github.com/tigisoftware/rootlessJB3

## PLEASE DO MANUALLY, DON'T USE ANY ROOTLESS INSTALLER TOOLS ##

Installation:
1. Copy all files into following folders
2. Set Permission to:

#unrar & zip bundle files in folder:
/var/containers/Bundle/tweaksupport/bin/
unrar, unzip, zip, zipcloak, zipnote, zipsplit
Ownership to root & staff (0:0)
Permission to 0777

#Filza Daemon plist in folder:
/var/containers/Bundle/tweaksupport/Library/LaunchDaemons/
com.tigisoftware.filza.helper.plist
Ownership to root & staff (0:0)

#filza folder
(Create new folder "filza", no caps lock)
/var/containers/Bundle/tweaksupport/usr/libexec/filza
Ownership to root & staff (0:0)
Permision to 0777

#Filza bundle files in folder:
/var/containers/Bundle/tweaksupport/usr/libexec/filza
Filza, FilzaHelper, FilzaWebDAVServer
Ownership to root & staff (0:0)
Permision to 0777

3. No inject, just Reboot & Rejailbreak
4. Profit